# ASP.NET MVC5: REST Web API Routing with different names

For detail tutorial Visit: https://bit.ly/2B3gPUF
