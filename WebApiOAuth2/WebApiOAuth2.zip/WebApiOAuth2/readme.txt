# ASP.NET MVC: OAuth 2.0 REST Web API Authorization using Database First Approach

For detail tutorial Visit: https://bit.ly/2Ka3NpZ
